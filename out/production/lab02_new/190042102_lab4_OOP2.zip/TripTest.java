import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TripTest {
	List<Vehicle> list=new LinkedList<Vehicle>();
	
	@Test
	public void Sedan() {
		Vehicle vehicle=new Vehicle("SEDAN",50,30,5,26);
		Trip2 trip2=new Trip2(10,10,3,300);
		int actual = Per_head_fare.perHeadFare(vehicle,trip2);
		Assertions.assertEquals(120, actual);
	}
	
	@Test
	public void MotorBike_LessThan25() {
		Vehicle vehicle=new Vehicle("MOTOR_BIKE",25,20,1,10);
		Trip2 trip2=new Trip2(1,2,1,300);
		int actual = Per_head_fare.perHeadFare(vehicle,trip2);
		Assertions.assertEquals(25, actual);
	}
	
	@Test
	public void MotorBike_MoreThan25() {
		Vehicle vehicle=new Vehicle("MOTOR_BIKE",25,20,1,10);
		Trip2 trip2=new Trip2(5,15,1,300);
		int actual = Per_head_fare.perHeadFare(vehicle,trip2);
		//double actual = new Trip("MOTOR_BIKE", 5, 15, 1).perHeadFare();
		Assertions.assertEquals(100, actual);
	}
	
	
	@Test
	public void SevenSeater_LessThan10KM() {
		Vehicle vehicle=new Vehicle("SEVEN_SEATER",25,20,1,10);
		Trip2 trip2=new Trip2(1,2,7,300);
		int actual = Per_head_fare.perHeadFare(vehicle,trip2);
		//double actual = new Trip("SEVEN_SEATER", 1, 2, 7).perHeadFare();
		Assertions.assertEquals(40, actual);
	}
	
	@Test
	public void SevenSeater_MoreThan2KM() {
		Vehicle vehicle=new Vehicle("SEVEN_SEATER",25,20,1,10);
		Trip2 trip2=new Trip2(100,200,6,300);
		int actual = Per_head_fare.perHeadFare(vehicle,trip2);
		//double actual = new Trip("SEVEN_SEATER", 100, 200, 6).perHeadFare();
		Assertions.assertEquals(500, actual);
	}
	
}