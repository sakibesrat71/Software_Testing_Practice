public class Trip_decider {
//Vehicle vehicle;
Trip2 trip2;
//	public Trip_decider(Vehicle vehicle, Trip2 trip2) {
//		this.vehicle = vehicle;
//		this.trip2 = trip2;
//	}
	public static boolean canTakeTrip(Vehicle vehicle, Trip2 trip2) {
		if (trip2.numberOfPassenger < 1)
			return false;
		
		switch (vehicle.name) {
			case "SEDAN":
				return trip2.numberOfPassenger <= vehicle.minimum_number_of_passenger && trip2.distance <= vehicle.minimum_distance;
			case "SEVEN_SEATER":
				return trip2.numberOfPassenger <= vehicle.minimum_number_of_passenger && trip2.distance >= vehicle.minimum_distance;
			default:
				return trip2.numberOfPassenger<= vehicle.minimum_number_of_passenger && trip2.distance <= 10;
		}
	}
}
