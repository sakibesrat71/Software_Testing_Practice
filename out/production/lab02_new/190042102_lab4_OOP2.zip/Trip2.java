public class Trip2 {
	public int distance;
	public int minutes;
	public int numberOfPassenger;
	public int minimumFarefortrip;
	
	public Trip2(int distance, int minutes, int numberOfPassenger,int minimumFarefortrip) {
		this.distance = distance;
		this.minutes = minutes;
		this.numberOfPassenger = numberOfPassenger;
		this.minimumFarefortrip=minimumFarefortrip;
	}
}
