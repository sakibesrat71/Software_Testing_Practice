public class RequestTrip {
Vehicle vehicle;
Trip_decider trip_decider;
	public static void requestTrip(Vehicle vehicle,Trip_decider trip_decider,Trip2 trip2) {
		vehicle.msgAfterChoosingVehicle();
		
		if (Trip_decider.canTakeTrip(vehicle,trip2)) {
			System.out.println(trip_decider.trip2.distance + " KM");
			System.out.println(trip_decider.trip2.minutes + " Minutes");
			//System.out.println(perHeadFare() + " Taka Per Person");
		} else {
			System.out.println("Invalid Trip Request");
		}
	}
}
